package newselpackage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SelClass {
	 
		public static void main(String[] args) throws InterruptedException {
				
			// Access the local path of the Google Chrome web driver
			System.setProperty("webdriver.chrome.driver", "C://selenium-2.25.0/chromedriver.exe");
			
			// Create a new instance of the Google Chrome driver
			WebDriver driver = new ChromeDriver();
			
	        // Launch the Marine Traffic embedded map
			driver.get("https://www.marinetraffic.com/en/ais/embed");
	 
	        // Print a success message to the console
	        System.out.println("Successfully opened www.marinetraffic.com/en/ais/embed");
	 
		    // Find the Map Layer button by xpath and click it to reveal the checkboxes
			driver.findElement(By.xpath("id(\"map_area_outer\")/div[2]/div[@class=\"main-panel d-flex\"]/div[1]/div[@class=\"main-panel-inner d-flex flex-column\"]/div[@class=\"flex-1-0-auto d-flex flex-column align-items-center\"]/div[@class=\"map-menu-btn d-flex align-items-center justify-content-center pnd_map_layers_btn\"]")).click();
			
			// Check if the Port checkbox is not selected
			if ( !driver.findElement(By.xpath("(//input[@value='on'])[3]")).isSelected() )
			{
				//Wait for 2 Sec
				Thread.sleep(2000);
				
				// Click the Port checkbox
			    driver.findElement(By.xpath("(//input[@value='on'])[3]")).click();
			    
			    // Print a success message to the console
			    System.out.println("Successfully checked the Ports checkbox");
				 
				Thread.sleep(2000);
			}
	
			// Check if the Stations checkbox is not selected
			if ( !driver.findElement(By.xpath("(//input[@value='on'])[4]")).isSelected() )
			{
				
				Thread.sleep(2000);
				
			    driver.findElement(By.xpath("(//input[@value='on'])[4]")).click();
			    
			    System.out.println("Successfully checked the Stations checkbox");
			 
				Thread.sleep(2000);
			}
			
			// Check if the Lights and AtoN checkbox is not selected
			if ( !driver.findElement(By.xpath("(//input[@value='on'])[5]")).isSelected() )
			{
				
				Thread.sleep(2000);
				
			    driver.findElement(By.xpath("(//input[@value='on'])[5]")).click();
			    
			    System.out.println("Successfully checked the Lights and AtoN checkbox");
			 
				Thread.sleep(2000);
			}
			
			// Check if the Photos checkbox is not selected
			if ( !driver.findElement(By.xpath("(//input[@value='on'])[6]")).isSelected() )
			{
				
				Thread.sleep(2000);
				
			    driver.findElement(By.xpath("(//input[@value='on'])[6]")).click();
			    
			    System.out.println("Successfully checked the Photos checkbox");
			  
				Thread.sleep(2000);
			} 
			
				System.out.println("The Ports, Stations, Lights and Photos layers are correctly displayed on the embedded map");	
							
	        // Close the driver
	        driver.quit();
	    }
	}
